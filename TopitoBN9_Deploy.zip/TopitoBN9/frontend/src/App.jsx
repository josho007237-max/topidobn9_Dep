
import React from 'react';

export default function App() {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Topito Dashboard</h1>
      <p>แดชบอร์ดสำหรับจัดการ Telegram Bot & Mini App</p>
    </div>
  );
}
