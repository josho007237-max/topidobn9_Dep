
# Topito BN9 - Telegram Bot Dashboard

## วิธีใช้งาน

1. กรอกค่าใน `.env`
2. รัน `npm install` และ `npm start` ใน backend
3. เข้า `frontend` แล้วรัน `npm install` และ `npm run dev`
4. ตั้ง webhook ให้กับบอท

## Deploy

- สำหรับ Netlify: ใช้ `frontend/`
- สำหรับ Replit: ใช้ทั้ง `frontend/` และ `backend/`
