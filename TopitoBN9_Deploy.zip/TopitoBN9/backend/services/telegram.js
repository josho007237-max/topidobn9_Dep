
const axios = require('axios');

const TELEGRAM_API = 'https://api.telegram.org/bot' + process.env.TELEGRAM_BOT_TOKEN;

async function handleTelegramUpdate(update) {
  if (update.message) {
    const chatId = update.message.chat.id;
    const text = update.message.text;
    await axios.post(TELEGRAM_API + '/sendMessage', {
      chat_id: chatId,
      text: 'คุณพิมพ์ว่า: ' + text,
    });
  }
}

module.exports = { handleTelegramUpdate };
